import { useState, useEffect } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const bannerImages = [
  "https://images.unsplash.com/photo-1561060511-78b14b799fe1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBmYXNoaW9uJTIwaGF1dGUlMjBjb3V0dXJlfGVufDF8fHx8MTc2MTMwODA0Mnww&ixlib=rb-4.1.0&q=80&w=1080",
  "https://images.unsplash.com/photo-1619384846683-8dede3452564?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbW9kZWwlMjBlbGVnYW50fGVufDF8fHx8MTc2MTIxMzQzN3ww&ixlib=rb-4.1.0&q=80&w=1080",
  "https://images.unsplash.com/photo-1755514838747-adfd34197d39?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBmYXNoaW9uJTIwcnVud2F5fGVufDF8fHx8MTc2MTI1MTI2OHww&ixlib=rb-4.1.0&q=80&w=1080",
  "https://images.unsplash.com/photo-1619947665093-b8018e3dd1a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwcGhvdG9ncmFwaHklMjBlbGVnYW50fGVufDF8fHx8MTc2MTMwODA0OHww&ixlib=rb-4.1.0&q=80&w=1080",
];

export function HomePage() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide(
        (prev) => (prev + 1) % bannerImages.length,
      );
    }, 5000); // Change image every 5 seconds

    return () => clearInterval(interval);
  }, []);
  return (
    <div>
      {/* Hero Section */}
      <section className="relative border-b border-border">
        <div className="relative h-[400px] md:h-[600px] lg:h-[700px] overflow-hidden">
          {bannerImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide
                  ? "opacity-100"
                  : "opacity-0"
              }`}
            >
              <ImageWithFallback
                src={image}
                alt={`Gallery Exhibition ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/15 to-transparent"></div>
          <div className="absolute inset-0 flex items-center justify-center px-4">
            <div className="text-center">
              <div className="inline-block px-10 md:px-20 py-8 md:py-12 bg-ivoire-satine/95 backdrop-blur-sm">
                <div
                  className="text-noir-onyx mb-8"
                  style={{
                    fontFamily: "var(--font-sans)",
                    fontSize: "clamp(0.9rem, 2vw, 1.5rem)",
                    letterSpacing: "-0.02em",
                    fontWeight: 400,
                  }}
                >
                  ATELIER NUA
                </div>
                <button className="px-8 md:px-10 py-3 rounded-full bg-primary text-primary-foreground hover:opacity-90 transition-opacity">
                  Découvrir
                </button>
              </div>
            </div>
          </div>

          {/* Carousel Dots */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
            {bannerImages.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentSlide
                    ? "bg-ivoire-satine w-8"
                    : "bg-ivoire-satine/50 hover:bg-ivoire-satine/75"
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Current Exhibitions */}
      <section className="container mx-auto px-4 md:px-6 py-12 md:py-20">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 md:mb-12 gap-4">
          <h2 className="text-foreground">Actuellement</h2>
          <button className="px-6 md:px-8 py-2 rounded-full border border-gris-perle text-gris-charbon hover:border-primary hover:text-primary transition-all">
            Tout voir →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          <div className="group cursor-pointer">
            <div className="bg-card overflow-hidden mb-4">
              <div className="h-64 md:h-80 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1758362197676-228703a17e69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMGpld2VscnklMjBsdXh1cnl8ZW58MXx8fHwxNzYxMzA4MDQyfDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Exposition de bijoux et mode"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
            <div className="space-y-2">
              <h3 className="text-primary">Éclats Précieux</h3>
              <p className="text-gris-charbon">
                Une collection raffinée de bijoux contemporains
              </p>
              <p className="text-muted-foreground italic font-accent">
                Jusqu'au 15 mars 2026
              </p>
            </div>
          </div>

          <div className="group cursor-pointer">
            <div className="bg-card overflow-hidden mb-4">
              <div className="h-64 md:h-80 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1758171692659-024183c2c272?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBoYW5kYmFnJTIwZGVzaWduZXJ8ZW58MXx8fHwxNzYxMjU1NDAwfDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Sac à main de luxe"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
            <div className="space-y-2">
              <h3 className="text-primary">
                L'Or de la Maison
              </h3>
              <p className="text-gris-charbon">
                Maroquinerie d'exception et savoir-faire
                artisanal
              </p>
              <p className="text-muted-foreground italic font-accent">
                Jusqu'au 28 février 2026
              </p>
            </div>
          </div>

          <div className="group cursor-pointer">
            <div className="bg-card overflow-hidden mb-4">
              <div className="h-64 md:h-80 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1571682262898-48532c58b3a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZXZlbmluZyUyMGdvd258ZW58MXx8fHwxNzYxMjUxMzI3fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Robe de soirée haute couture"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
            <div className="space-y-2">
              <h3 className="text-primary">
                Silhouettes Intemporelles
              </h3>
              <p className="text-gris-charbon">
                L'élégance de la haute couture revisitée
              </p>
              <p className="text-muted-foreground italic font-accent">
                Jusqu'au 10 avril 2026
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Content */}
      <section className="bg-gris-perle py-12 md:py-20">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-foreground mb-8 md:mb-12 text-center">
            À découvrir
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 max-w-6xl mx-auto">
            <div className="group cursor-pointer bg-card">
              <div className="h-64 md:h-96 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1699052151128-3675016dec3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwZmFzaGlvbiUyMGNvdXR1cmV8ZW58MXx8fHwxNzYxMzA4MDQ0fDA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Mannequin en manteau vintage avec haut-de-forme"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-6 md:p-8 space-y-3">
                <h3 className="text-primary">
                  L'Élégance Androgyne
                </h3>
                <p className="text-gris-charbon">
                  Découvrez une mode féminine audacieuse
                  inspirée du vestiaire masculin classique, où
                  le raffinement intemporel rencontre l'audace
                  contemporaine.
                </p>
              </div>
            </div>
            <div className="group cursor-pointer bg-card">
              <div className="h-64 md:h-96 overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1630955110816-6fbcd2b87de4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXV0ZSUyMGNvdXR1cmUlMjBkcmVzc3xlbnwxfHx8fDE3NjEyNDMxNjd8MA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Collection de robes haute couture avec fresques classiques"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-6 md:p-8 space-y-3">
                <h3 className="text-primary">Art & Couture</h3>
                <p className="text-gris-charbon">
                  Plongez dans l'univers où l'art rencontre la
                  haute couture. Une exposition exceptionnelle
                  célébrant la beauté des silhouettes dans un
                  cadre architectural d'exception.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="container mx-auto px-4 md:px-6 py-12 md:py-20">
        <div className="max-w-2xl mx-auto text-center">
          <h3 className="text-primary mb-3">Restez informé</h3>
          <p className="text-gris-charbon mb-8 italic font-accent">
            Recevez nos actualités et invitations exclusives
          </p>
          <div className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <input
              type="email"
              placeholder="Votre adresse email"
              className="flex-1 px-5 py-3 rounded-full border border-gris-perle bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
            />
            <button className="px-8 py-3 rounded-full bg-primary text-primary-foreground hover:opacity-90 transition-opacity whitespace-nowrap">
              S'inscrire
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
