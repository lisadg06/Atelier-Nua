import { ImageWithFallback } from "./figma/ImageWithFallback";

const exhibitions = [
  {
    id: 1,
    image: "https://images.unsplash.com/photo-1699052151128-3675016dec3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwZmFzaGlvbiUyMGNvdXR1cmV8ZW58MXx8fHwxNzYxMzA4MDQ0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Dior New Look : L'Élégance Intemporelle",
    description:
      "Découvrez l'héritage du New Look de Christian Dior à travers une collection exceptionnelle de silhouettes iconiques des années 1947 à nos jours.",
    dates: "15 Mars - 30 Juin 2025",
  },
  {
    id: 2,
    image: "https://images.unsplash.com/photo-1758362197676-228703a17e69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMGpld2VscnklMjBsdXh1cnl8ZW58MXx8fHwxNzYxMzA4MDQyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Bijoux & Accessoires : L'Art du Détail",
    description:
      "Une exposition immersive consacrée aux créations joaillières et accessoires de luxe qui ont défini l'élégance Dior à travers les décennies.",
    dates: "1er Avril - 15 Juillet 2025",
  },
  {
    id: 3,
    image: "https://images.unsplash.com/photo-1758171692659-024183c2c272?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBoYW5kYmFnJTIwZGVzaWduZXJ8ZW58MXx8fHwxNzYxMjU1NDAwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Lady Dior : Icône Dorée",
    description:
      "Célébration du sac Lady Dior, symbole intemporel de raffinement et savoir-faire artisanal, présenté dans ses versions les plus prestigieuses et rares.",
    dates: "10 Mai - 31 Août 2025",
  },
  {
    id: 4,
    image: "https://images.unsplash.com/photo-1571682262898-48532c58b3a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZXZlbmluZyUyMGdvd258ZW58MXx8fHwxNzYxMjUxMzI3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "Couture Retrospective : 75 Ans d'Excellence",
    description:
      "Un voyage chronologique à travers les créations les plus emblématiques de la Maison Dior, célébrant trois quarts de siècle d'innovation en haute couture.",
    dates: "1er Juin - 30 Septembre 2025",
  },
];

export function ExhibitionsPage() {
  return (
    <div>
      {/* Page Header */}
      <section className="bg-gris-perle py-12 md:py-20">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h1 className="text-primary">Expositions</h1>
          <p className="text-gris-charbon mt-6 italic font-accent max-w-2xl mx-auto">
            Explorez nos expositions actuelles et à venir
            célébrant l'art de la haute couture
          </p>
        </div>
      </section>

      {/* Exhibitions Grid */}
      <section className="container mx-auto px-4 md:px-6 py-12 md:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 md:gap-10 mb-12 md:mb-16 max-w-6xl mx-auto">
          {exhibitions.map((expo) => (
            <div key={expo.id} className="group cursor-pointer">
              <div className="bg-card overflow-hidden mb-5 border border-gris-perle">
                <div className="h-72 md:h-96 overflow-hidden">
                  <ImageWithFallback
                    src={expo.image}
                    alt={expo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
              </div>
              <div className="space-y-3">
                <h3 className="text-primary group-hover:text-accent transition-colors">
                  {expo.title}
                </h3>
                <p className="text-gris-charbon leading-relaxed">
                  {expo.description}
                </p>
                <div className="flex gap-3 items-center flex-wrap text-sm text-gris-charbon pt-2">
                  <span className="italic font-accent">
                    {expo.dates}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
