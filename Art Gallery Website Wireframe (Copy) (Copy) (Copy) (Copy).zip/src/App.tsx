import { useState } from "react";
import { Layout } from "./components/Layout";
import { HomePage } from "./components/HomePage";
import { ExhibitionsPage } from "./components/ExhibitionsPage";
import { VisitPage } from "./components/VisitPage";
import { AboutPage } from "./components/AboutPage";

export default function App() {
  const [currentPage, setCurrentPage] = useState("Home");

  const renderPage = () => {
    switch (currentPage) {
      case "Home":
        return <HomePage />;
      case "Exhibitions":
        return <ExhibitionsPage />;
      case "Visit":
        return <VisitPage />;
      case "About":
        return <AboutPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <Layout
      currentPage={currentPage}
      onNavigate={setCurrentPage}
    >
      {renderPage()}
    </Layout>
  );
}