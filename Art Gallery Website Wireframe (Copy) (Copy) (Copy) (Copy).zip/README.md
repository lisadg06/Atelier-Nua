
  # Art Gallery Website Wireframe (Copy) (Copy) (Copy) (Copy)

  This is a code bundle for Art Gallery Website Wireframe (Copy) (Copy) (Copy) (Copy). The original project is available at https://www.figma.com/design/8x2j9PICrLq4MxkdlSMfLs/Art-Gallery-Website-Wireframe--Copy---Copy---Copy---Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  